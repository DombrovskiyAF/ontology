#include "vz_settings.h"


QString vzsetNumber;
QString vzsetStringId;
QString vzsetHierarhRole;
QString vzsetDependRole;
